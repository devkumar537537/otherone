package com.example.servicesexample;

public class AppConstant {
    public static final String YES_ACTION = "YES_ACTION";
    public static final String STOP_ACTION = "STOP_ACTION";
}
